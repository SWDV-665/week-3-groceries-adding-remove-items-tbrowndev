import { Component } from '@angular/core';
import { NavController, Item } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage {
  
  title = "Groceries List";
  items = [
    {
      name:"Milk",
      quantity: 1
    },
    {
      name:"Eggs",
      quantity: 2
    },
    {
      name:"Bread",
      quantity: 1
    },
    {
      name:"Cheese",
      quantity: 2
    },
    {
      name:"Butter",
      quantity: 1
    },
    {
      name:"Popcorn",
      quantity: 3
    }
  ];

  constructor(public navCtrl: NavController, public toastCtrl:ToastController, public alertCtrl: AlertController) {

  }

  removeItem(item, index){
    //console.log("Item Removed: ", item)
    this.items.splice(index, 1);
    const toast = this.toastCtrl.create({
      message: item.name + " Removed",
      duration: 5000,
      showCloseButton: true
    });
    toast.present();
  }

  completeItem(item, index){
    //console.log("Completed Item: ", item)
    this.items.splice(index, 1);
    const toast = this.toastCtrl.create({
      message: item.name + " Completed",
      duration: 5000,
      showCloseButton: true
    });
    toast.present();
  }

  newItemPrompt(){
    //console.log("adding new item")
    const prompt = this.alertCtrl.create({
      title: "New Item alert!",
      message: "Enter New Item Details",
      inputs:[
        {
          name:"name",
          type: "text",
          placeholder: "Item Name"
        },
        {
          name:"quantity",
          type: "number",
          min: 1,
          max: 99,
          placeholder: "Quantity"
        }
      ],
      buttons: [
        {
          text: "Cancel",
          handler: () => {

          }
        },
        {
          text: "Add",
          handler: item => {
            this.items.push(item);
          }
        }
      ]
    })
    prompt.present();
  }

}
